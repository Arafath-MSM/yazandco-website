class CartRemoveButton extends HTMLElement {
	constructor() {
		super();

		this.addEventListener("click", (event) => {
			event.preventDefault();
			const cartItems =
				this.closest("cart-items") || this.closest("cart-drawer-items");
			cartItems.updateQuantity(this.dataset.index, 0);
		});
	}
}

customElements.define("cart-remove-button", CartRemoveButton);

class CartItems extends HTMLElement {
	constructor() {
		super();
		this.lineItemStatusElement =
			document.getElementById("shopping-cart-line-item-status") ||
			document.getElementById("CartDrawer-LineItemStatus");

		if (document.querySelector(".cart-shipping")) {
			this.minSpend = document.querySelector(".cart-shipping").dataset.minSpend;
			this.minTotal = Math.round(this.minSpend * (Shopify.currency.rate || 1));
			this.cartShipping();
		}

		const debouncedOnChange = debounce((event) => {
			this.onChange(event);
		}, ON_CHANGE_DEBOUNCE_TIMER);

		this.addEventListener("change", debouncedOnChange.bind(this));
	}

	cartUpdateUnsubscriber = undefined;

	cartShipping() {
		const progressCurrent = document.querySelector(
			".cart-shipping__progress-current"
		);
		const shipping = document.querySelector(".cart-shipping");
		const messageDefault = document.querySelector(
			".cart-shipping__message_default"
		);
		const messageSuccess = document.querySelector(
			".cart-shipping__message_success"
		);
		// This runs from the constructor: a single missing node used to throw and
		// stop <cart-items> / <cart-drawer-items> from upgrading at all.
		if (!progressCurrent || !shipping || !messageDefault || !messageSuccess)
			return;

		let progressPrev = getComputedStyle(progressCurrent).getPropertyValue(
			"width"
		);
		document.documentElement.style.setProperty("--progress-prev", progressPrev);

		this.total = document.querySelector(".cart-shipping").dataset.total;
		this.progress = (this.total / this.minTotal) * 100;
		if (this.progress > 100) this.progress = 100;

		if (this.minTotal > this.total) {
			let amount = this.minTotal - this.total;
			let message = document
				.querySelector(".cart-shipping")
				.dataset.message.replace("||amount||", formatMoney(amount));
			document.querySelector(".cart-shipping__message_default").innerHTML =
				message;
			document
				.querySelector(".cart-shipping__message_success")
				.classList.remove("active");
			document
				.querySelector(".cart-shipping__message_default")
				.classList.add("active");
		} else {
			document
				.querySelector(".cart-shipping__message_default")
				.classList.remove("active");
			document
				.querySelector(".cart-shipping__message_success")
				.classList.add("active");
		}
		document.querySelector(".cart-shipping__progress-current").style.width =
			this.progress + "%";
	}

	connectedCallback() {
		this.cartUpdateUnsubscriber = subscribe(
			PUB_SUB_EVENTS.cartUpdate,
			(event) => {
				if (event.source === "cart-items") {
					return;
				}
				this.onCartUpdate();
			}
		);
	}

	disconnectedCallback() {
		if (this.cartUpdateUnsubscriber) {
			this.cartUpdateUnsubscriber();
		}
	}

	onChange(event) {
		this.updateQuantity(
			event.target.dataset.index,
			event.target.value,
			document.activeElement.getAttribute("name")
		);
	}

	onCartUpdate() {
		// Only the cart PAGE refreshes itself from the main-cart-items section.
		// <cart-drawer-items> inherits this method, and every add-to-cart publishes
		// cartUpdate - which used to pull the cart-page markup and write it straight
		// into the drawer, replacing the drawer's own line items (and racing with
		// CartDrawer.renderContents, which had already rendered them correctly).
		if (this.tagName !== "CART-ITEMS") return;

		fetch(`${routes.cart_url}?section_id=main-cart-items`)
			.then((response) => response.text())
			.then((responseText) => {
				const html = new DOMParser().parseFromString(responseText, "text/html");
				const sourceQty = html.querySelector("cart-items");
				if (!sourceQty) return;
				this.innerHTML = sourceQty.innerHTML;
			})
			.catch((e) => {
				console.error(e);
			});
	}

	getSectionsToRender() {
		return [
			{
				id: "main-cart-items",
				section: document.getElementById("main-cart-items").dataset.id,
				selector: ".js-contents",
			},
			{
				id: "cart-icon-bubble",
				section: "cart-icon-bubble",
				selector: ".shopify-section",
			},
			{
				id: "cart-live-region-text",
				section: "cart-live-region-text",
				selector: ".shopify-section",
			},
			{
				id: "main-cart-footer",
				section: document.getElementById("main-cart-footer").dataset.id,
				selector: ".js-contents-totals",
			},
			{
				id: "main-cart-shipping",
				section:
					document.getElementById("main-cart-shipping").dataset.id || null,
				selector: ".js-contents-shipping",
			},
		];
	}

	updateQuantity(line, quantity, name) {
		this.enableLoading(line);
		this.querySelectorAll(".quantity__button").forEach((button) =>
			button.classList.add("disabled")
		);

		if (
			document.querySelectorAll(
				'.card--product card__add-to-cart button[name="add"]'
			)
		) {
			document
				.querySelectorAll(
					'.card--product .card__add-to-cart button[name="add"]'
				)
				.forEach((button) => {
					button.setAttribute("aria-disabled", false);
					if (button.querySelector("span")) {
						button.querySelector("span").classList.remove("hidden");
						button.querySelector(".sold-out-message").classList.add("hidden");
					}
				});
		}

		if (document.querySelector(".cart-shipping")) {
			let progressPrev = getComputedStyle(
				document.querySelector(".cart-shipping__progress-current")
			).getPropertyValue("width");
			document.documentElement.style.setProperty(
				"--progress-prev",
				progressPrev
			);
		}

		const body = JSON.stringify({
			line,
			quantity,
			sections: this.getSectionsToRender().map((section) => section.section),
			sections_url: window.location.pathname,
		});

		fetch(`${routes.cart_change_url}`, { ...fetchConfig(), ...{ body } })
			.then((response) => {
				return response.text();
			})
			.then((state) => {
				const parsedState = JSON.parse(state);
				const quantityElement =
					document.getElementById(`Quantity-${line}`) ||
					document.getElementById(`Drawer-quantity-${line}`);
				const items = document.querySelectorAll(".cart-item");
				if (parsedState.errors) {
					quantityElement.value = quantityElement.getAttribute("value");
					this.updateLiveRegions(line, parsedState.errors);

					// dispatch cart:error
					document.dispatchEvent(
						new CustomEvent("cart:error", {
							detail: { line, errors: parsedState.errors },
						})
					);
					return;
				}

				// dispatch line-item:change for the modified element
				document.dispatchEvent(
					new CustomEvent("line-item:change", {
						detail: {
							lineItem: parsedState.items[line - 1] || null,
							cart: parsedState,
						},
					})
				);

				this.classList.toggle("is-empty", parsedState.item_count === 0);

				// dispatch cart:change for the entire basket
				document.dispatchEvent(
					new CustomEvent("cart:change", { detail: { cart: parsedState } })
				);

				const cartDrawerWrapper = document.querySelector("cart-drawer");
				const cartFooter = document.getElementById("main-cart-footer");

				if (cartFooter)
					cartFooter.classList.toggle("is-empty", parsedState.item_count === 0);
				if (cartDrawerWrapper)
					cartDrawerWrapper.classList.toggle(
						"is-empty",
						parsedState.item_count === 0
					);

				this.getSectionsToRender().forEach((section) => {
					const container = document.getElementById(section.id);
					if (!container) return;
					const elementToReplace =
						container.querySelector(section.selector) || container;
					const markup = this.getSectionInnerHTML(
						parsedState.sections[section.section],
						section.selector
					);
					// A missing section key used to throw here, turning a SUCCESSFUL
					// cart update into a visible "there was an error" message.
					if (markup === null) return;
					elementToReplace.innerHTML = markup;
				});
				const updatedValue = parsedState.items[line - 1]
					? parsedState.items[line - 1].quantity
					: undefined;
				let message = "";
				if (
					items.length === parsedState.items.length &&
					updatedValue !== parseInt(quantityElement.value)
				) {
					if (typeof updatedValue === "undefined") {
						message = window.cartStrings.error;
					} else {
						message = window.cartStrings.quantityError.replace(
							"[quantity]",
							updatedValue
						);
					}
				}
				this.updateLiveRegions(line, message);

				const lineItem =
					document.getElementById(`CartItem-${line}`) ||
					document.getElementById(`CartDrawer-Item-${line}`);
				if (lineItem && lineItem.querySelector(`[name="${name}"]`)) {
					cartDrawerWrapper
						? trapFocus(
								cartDrawerWrapper,
								lineItem.querySelector(`[name="${name}"]`)
						  )
						: lineItem.querySelector(`[name="${name}"]`).focus();
				} else if (parsedState.item_count === 0 && cartDrawerWrapper) {
					trapFocus(
						cartDrawerWrapper.querySelector(".drawer__inner-empty"),
						cartDrawerWrapper.querySelector("a")
					);
				} else if (document.querySelector(".cart-item") && cartDrawerWrapper) {
					trapFocus(
						cartDrawerWrapper,
						document.querySelector(".cart-item__name")
					);
				}
				publish(PUB_SUB_EVENTS.cartUpdate, { source: "cart-items" });
			})
			.catch(() => {
				this.querySelectorAll(".loading-overlay").forEach((overlay) =>
					overlay.classList.add("hidden")
				);
				this.querySelectorAll(".quantity__button").forEach((button) =>
					button.classList.remove("disabled")
				);
				const errors =
					document.getElementById("cart-errors") ||
					document.getElementById("CartDrawer-CartErrors");
				errors.textContent = window.cartStrings.error;

				// dispatch cart:error when fetch fail
				document.dispatchEvent(
					new CustomEvent("cart:error", {
						detail: { errors: window.cartStrings.error },
					})
				);
			})
			.finally(() => {
				this.querySelectorAll(".quantity__button").forEach((button) =>
					button.classList.remove("disabled")
				);
				if (document.querySelector(".cart-shipping")) {
					this.cartShipping();
				}
				this.disableLoading(line);
			});
	}

	updateLiveRegions(line, message) {
		const lineItemError =
			document.getElementById(`Line-item-error-${line}`) ||
			document.getElementById(`CartDrawer-LineItemError-${line}`);
		if (lineItemError)
			lineItemError.querySelector(".cart-item__error-text").innerHTML = message;

		this.lineItemStatusElement?.setAttribute("aria-hidden", true);

		const cartStatus =
			document.getElementById("cart-live-region-text") ||
			document.getElementById("CartDrawer-LiveRegionText");
		if (!cartStatus) return;
		cartStatus.setAttribute("aria-hidden", false);

		setTimeout(() => {
			cartStatus.setAttribute("aria-hidden", true);
		}, 1000);
	}

	getSectionInnerHTML(html, selector) {
		if (typeof html !== "string") return null;
		const found = new DOMParser()
			.parseFromString(html, "text/html")
			.querySelector(selector);
		return found ? found.innerHTML : null;
	}

	enableLoading(line) {
		const mainCartItems =
			document.getElementById("main-cart-items") ||
			document.getElementById("CartDrawer-CartItems");
		mainCartItems?.classList.add("cart__items--disabled");

		const cartItemElements = this.querySelectorAll(
			`#CartItem-${line} .loading-overlay`
		);
		const cartDrawerItemElements = this.querySelectorAll(
			`#CartDrawer-Item-${line} .loading-overlay`
		);

		[...cartItemElements, ...cartDrawerItemElements].forEach((overlay) =>
			overlay.classList.remove("hidden")
		);

		document.activeElement?.blur();
		this.lineItemStatusElement?.setAttribute("aria-hidden", false);
	}

	disableLoading(line) {
		const mainCartItems =
			document.getElementById("main-cart-items") ||
			document.getElementById("CartDrawer-CartItems");
		mainCartItems?.classList.remove("cart__items--disabled");

		const cartItemElements = this.querySelectorAll(
			`#CartItem-${line} .loading-overlay`
		);
		const cartDrawerItemElements = this.querySelectorAll(
			`#CartDrawer-Item-${line} .loading-overlay`
		);

		cartItemElements.forEach((overlay) => overlay.classList.add("hidden"));
		cartDrawerItemElements.forEach((overlay) =>
			overlay.classList.add("hidden")
		);
	}
}

customElements.define("cart-items", CartItems);

if (!customElements.get("cart-note")) {
	customElements.define(
		"cart-note",
		class CartNote extends HTMLElement {
			constructor() {
				super();

				this.addEventListener(
					"input",
					debounce((event) => {
						const body = JSON.stringify({ note: event.target.value });
						fetch(`${routes.cart_update_url}`, {
							...fetchConfig(),
							...{ body },
						});
					}, ON_CHANGE_DEBOUNCE_TIMER)
				);
			}
		}
	);
}
